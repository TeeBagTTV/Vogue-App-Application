package edu.pl206566.test;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/*
La classe SignUpActivity est une activité Android qui gère le processus d'inscription des utilisateurs.
 */
public class SignUpActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private EditText editTextEmail;
    private EditText editTextPassword;

    /*
    Cette méthode est appelée lors de la création de l'activité.
    Elle initialise Firebase Authentication (mAuth) et récupère les références des champs de saisie d'email et de mot de passe.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        mAuth = FirebaseAuth.getInstance();


        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);

        setupClickableTextView();
    }

    /*
    Cette méthode est appelée lorsqu'un utilisateur appuie sur le bouton d'inscription.
    Elle récupère l'email et le mot de passe saisis par l'utilisateur, puis utilise Firebase Authentication
    pour créer un nouvel utilisateur avec ces informations.
    Si l'inscription réussit, un e-mail de vérification est envoyé à l'utilisateur et il est redirigé vers l'écran de connexion (LoginActivity).
    Sinon, un message d'erreur est affiché.
     */
    public void onSignupPressed(View view) {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (!validateInput(email, password)) {
            Toast.makeText(SignUpActivity.this, "Email invalide ou mot de passe trop court.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                user.sendEmailVerification()
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Toast.makeText(SignUpActivity.this, "Inscription réussie. Vérifiez votre email.",
                                                            Toast.LENGTH_SHORT).show();
                                                    onSignUpPressed(view);
                                                } else {
                                                    Toast.makeText(SignUpActivity.this, "Erreur lors de l'envoi de l'email de vérification.",
                                                            Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });
                            }
                        } else {
                            Toast.makeText(SignUpActivity.this, "Échec de l'inscription : " + task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    /*
    Cette méthode est appelée pour rediriger l'utilisateur vers l'écran de connexion (LoginActivity) après une inscription réussie.
     */
    public void onSignUpPressed(View view){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    /*
    Cette méthode vérifie si l'email contient un caractère '@' et si le mot de passe a une longueur supérieure à 6 caractères.
    Elle est utilisée pour valider les données saisies par l'utilisateur avant de tenter de créer un compte.
     */
    private boolean validateInput(String email, String password) {
        return email.contains("@") && password.length() > 6;
    }


    /*
    Cette méthode configure un texte cliquable "Déjà un compte ? Connectez-vous" dans l'écran d'inscription.
    Lorsque l'utilisateur clique sur ce texte, il est redirigé vers l'écran de connexion (LoginActivity).
     */
    private void setupClickableTextView() {
        String text = "Déjà un compte ? Connectez-vous";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(true);
                ds.setColor(Color.parseColor("#B3FFFFFF"));
            }
        };
        ss.setSpan(clickableSpan, 17, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView textView = findViewById(R.id.textViewLoginAccount);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setHighlightColor(Color.TRANSPARENT);
    }

}


