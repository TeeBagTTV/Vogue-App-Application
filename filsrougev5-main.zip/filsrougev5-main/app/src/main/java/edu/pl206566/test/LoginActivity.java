package edu.pl206566.test;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.squareup.picasso.Picasso;

/*
La classe LoginActivity est une activité Android qui gère le processus de connexion des utilisateurs à l'application.
 */
public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private ImageView imageView;
    private static final String TAG = "LoginActivity";

    /*
    Cette méthode est appelée lorsque l'activité est créée.
    Elle configure la mise en page en associant les vues EditText pour le courriel et le mot de passe, et l'image ImageView.
    Elle initialise également l'instance FirebaseAuth pour gérer l'authentification des utilisateurs.
    Elle charge une image à partir d'une URL à l'aide de Picasso pour l'afficher dans l'ImageView.
    De plus, elle configure deux textes cliquables pour les options "Créer un compte" et "Mot de passe oublié".
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connexion);

        editTextEmail = findViewById(R.id.editTextLoginEmail);
        editTextPassword = findViewById(R.id.editTextLoginPassword);

        mAuth = FirebaseAuth.getInstance();

        imageView = findViewById(R.id.image_view);
        String imageUrl = "https://static.thenounproject.com/png/8090-200.png";

        Picasso.get().load(imageUrl).into(imageView, new com.squareup.picasso.Callback() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onError(Exception e) {
            }
        });

        setupClickableTextView();
        setupClickableTextViewPassword();
    }

    /*
    Cette méthode est appelée lorsque l'utilisateur appuie sur le bouton de connexion.
    Elle récupère le courriel et le mot de passe entrés par l'utilisateur, puis tente de les authentifier à l'aide de la
    méthode signInWithEmailAndPassword de FirebaseAuth.
    Si l'authentification réussit et que l'utilisateur a vérifié son adresse e-mail,
    elle récupère le jeton FCM (Firebase Cloud Messaging) de l'appareil et l'enregistre dans la base de données Firebase.
    Ensuite, elle lance l'activité suivante (ArticleActivity).
    Si l'utilisateur n'a pas encore vérifié son adresse e-mail, un message toast est affiché pour lui demander de le faire.
     */
    public void onLoginPressed(View view) {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null && user.isEmailVerified()) {
                                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
                                    @Override
                                    public void onComplete(@NonNull Task<String> task) {
                                        if (!task.isSuccessful()) {
                                            Toast.makeText(LoginActivity.this, "Échec de la récupération du token FCM.", Toast.LENGTH_SHORT).show();
                                            return;
                                        }
                                        String token = task.getResult();
                                        saveTokenToDatabase(user.getUid(), token);
                                        startAnimation(imageView);
                                        changeActivity(view);
                                    }
                                });
                            } else {
                                Toast.makeText(LoginActivity.this, "Veuillez vérifier votre email avant de vous connecter.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(LoginActivity.this, "Échec de la connexion : " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    /*
    Cette méthode lance l'activité suivante (ArticleActivity) après la connexion réussie de l'utilisateur.
     */
    public void changeActivity(View view) {
        Intent intent = new Intent(this, ArticleActivity.class);
        startActivity(intent);
        finish();
    }

    /*
    Cette méthode enregistre le jeton FCM de l'utilisateur dans la base de données Firebase sous le nœud correspondant à son ID utilisateur.
     */
    private void saveTokenToDatabase(String userId, String token) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users").child(userId);
        ref.child("token").setValue(token).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(LoginActivity.this, "L'utilisateur est bien connecté", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Échec de l'enregistrement du token.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
    Cette méthode anime la vue en la faisant glisser vers la droite et en la rendant transparente.
     */
    private void startAnimation(View view) {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        view.animate()
                .translationX(screenWidth)
                .alpha(0.0f)
                .setDuration(1000)
                .start();
    }

    /*
    Cette méthode configure le texte "Pas encore de compte ? Créer en un" comme un lien cliquable pour démarrer l'activité SignUpActivity.
     */
    private void setupClickableTextView() {
        String text = "Pas encore de compte ? Créer en un";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(true);
                ds.setColor(Color.parseColor("#B3FFFFFF"));
            }
        };
        ss.setSpan(clickableSpan, 23, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView textView = findViewById(R.id.textViewCreateAccount);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setHighlightColor(Color.TRANSPARENT);
    }


    /*
    Cette méthode configure le texte "Mot de passe oublié ?" comme un lien cliquable pour démarrer l'activité ForgotPasswordActivity.
     */
    private void setupClickableTextViewPassword() {
        String text = "Mot de passe oublié ?";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(true);
                ds.setColor(Color.WHITE);
            }
        };
        ss.setSpan(clickableSpan, 0, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView textView = findViewById(R.id.textViewForgotPassword);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setHighlightColor(Color.TRANSPARENT);
    }
}
