package edu.pl206566.test;

import android.os.Parcel;
import android.os.Parcelable;

/*
La classe Vehicule est une classe qui représente un véhicule dans l'application.
 */
public class Vehicule implements Parcelable {
    private String type_vehicule;
    private String modele;
    private String marque;
    private int prix;
    private String etat;
    private String description;
    private double note;
    private String picture;
    private String userID;
    private double sumRatings;
    private int nbRatings;

    private String LocID = "0";


    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    private String ID;

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getLocID() {
        return LocID;
    }

    public void setLocID(String locID) {
        LocID = locID;
    }


    /*
    Prend en paramètres toutes les informations nécessaires pour créer un objet Vehicule, y compris le type,
    le modèle, la marque, le prix, l'état, la description, l'image et l'ID de l'utilisateur propriétaire.
     */

    public Vehicule() {
    }

    public Vehicule(String type, String modele, String marque, int prix, String etat, String description, String picture, String UserId) {
        this.type_vehicule = type;
        this.modele = modele;
        this.marque = marque;
        this.prix = prix;
        this.etat = etat;
        this.description = description;
        this.picture = picture;
        this.userID= UserId;
        this.nbRatings = 0;
        this.sumRatings = 0.0;
    }

    /*
    Implémentation de l'interface Parcelable pour permettre la transmission de l'objet Vehicule entre les composants de l'application.
     */
    protected Vehicule(Parcel in) {
        type_vehicule = in.readString();
        modele = in.readString();
        marque = in.readString();
        prix = in.readInt();
        etat = in.readString();
        description = in.readString();
        note = in.readDouble();
        picture = in.readString();
        userID = in.readString();
        ID = in.readString();
        LocID = in.readString();
        sumRatings = in.readDouble();
        nbRatings = in.readInt();
    }

    public static final Creator<Vehicule> CREATOR = new Creator<Vehicule>() {
        @Override
        public Vehicule createFromParcel(Parcel in) {
            return new Vehicule(in);
        }

        @Override
        public Vehicule[] newArray(int size) {
            return new Vehicule[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(type_vehicule);
        dest.writeString(modele);
        dest.writeString(marque);
        dest.writeInt(prix);
        dest.writeString(etat);
        dest.writeString(description);
        dest.writeDouble(note);
        dest.writeString(picture);
        dest.writeString(userID);
        dest.writeString(ID);
        dest.writeString(LocID);
        dest.writeDouble(sumRatings);
        dest.writeInt(nbRatings);
    }

    public String getType_vehicule() {
        return type_vehicule;
    }

    public void setType_vehicule(String type_vehicule) {
        this.type_vehicule = type_vehicule;
    }

    public String getModele() {
        return modele;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix_loc(int prix_loc) {
        this.prix = prix_loc;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public double getSumRatings() {
        return sumRatings;
    }


    /*
    Renvoie le nombre total de notes attribuées au véhicule.
     */

    public int getNbRatings(){
        return nbRatings;
    }

    public void setSumRatings(double sumRatings) {
        this.sumRatings = sumRatings;
    }

    // Setter pour nbRatings
    public void setNbRatings(int nbRatings) {
        this.nbRatings = nbRatings;
    }

    /*
    Calcule la note moyenne du véhicule en fonction de la somme des notes et du nombre total de notes.
     */
    public double getRating() {

        if (nbRatings > 0) {
            return sumRatings / nbRatings;
        } else {
            return 0;
        }
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }
}
