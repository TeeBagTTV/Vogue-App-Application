package edu.pl206566.test;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

/*
La classe ForgotPasswordActivity est une activité Android permettant à l'utilisateur de réinitialiser son mot de passe
en saisissant son adresse e-mail.
 */
public class ForgotPasswordActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private EditText editTextEmail;

    /*
    Cette méthode est appelée lorsque l'activité est créée. Elle initialise l'instance de FirebaseAuth,
    récupère la référence de la vue EditText pour l'e-mail,
    configure le bouton de réinitialisation de mot de passe pour appeler la méthode resetPassword(),
    et configure le texte cliquable pour rediriger vers l'écran de connexion.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        mAuth = FirebaseAuth.getInstance();
        editTextEmail = findViewById(R.id.editTextEmail);

        findViewById(R.id.buttonResetPassword).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPassword();
            }
        });

        setupClickableTextView();

    }

    /*
    Cette méthode vérifie d'abord si l'e-mail est vide. Si c'est le cas, elle affiche un message d'erreur.
    Sinon, elle utilise l'instance de FirebaseAuth pour envoyer un e-mail de réinitialisation de mot de passe
    à l'adresse e-mail saisie par l'utilisateur.
    Elle affiche ensuite un message de réussite ou d'échec en fonction du résultat de l'envoi.
     */
    private void resetPassword() {
        String email = editTextEmail.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            editTextEmail.setError("L'addresse email est requise.");
            editTextEmail.requestFocus();
            return;
        }

        mAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(ForgotPasswordActivity.this, "Email Envoyé ! Vérifiez votre boîte de réception.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ForgotPasswordActivity.this, "Une erreur est survenue ! Veuillez essayez une nouvelle fois.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /*
    Cette méthode configure le texte cliquable "Déjà un compte ? Connectez-vous"
    pour rediriger vers l'écran de connexion lorsqu'il est cliqué.
    Elle crée un objet SpannableString pour le texte, définit la partie "Connectez-vous" comme cliquable
    et lui donne un style différent (souligné et couleur différente).
    Ensuite, elle affecte ce SpannableString à un TextView, lui attribue un mouvement de lien
    et supprime la couleur de surbrillance pour le rendre transparent.
     */
    private void setupClickableTextView() {
        String text = "Déjà un compte ? Connectez-vous";
        SpannableString ss = new SpannableString(text);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                // Intention pour démarrer LoginActivity
                Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
            }

            @Override
            public void updateDrawState(@NonNull TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(true);
                ds.setColor(Color.parseColor("#B3FFFFFF"));
            }
        };
        ss.setSpan(clickableSpan, 17, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView textView = findViewById(R.id.textViewLoginAccount);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        textView.setHighlightColor(Color.TRANSPARENT);
    }
}

