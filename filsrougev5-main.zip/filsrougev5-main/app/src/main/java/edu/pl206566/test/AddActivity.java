package edu.pl206566.test;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
La classe AddActivity est une activité Android qui permet à l'utilisateur d'ajouter un nouveau véhicule qu'il met en location,
avec une description, un prix, une marque, un modèle, un type, un état et une image.
 */

public class AddActivity extends AppCompatActivity {
    private EditText editTextDescription, editTextPrix;
    private Spinner spinnerMarque, spinnerModele;
    private RadioGroup radioGroupType, radioGroupEtat1, radioGroupEtat2;
    private Uri imageUri;
    private ImageView imageViewPreview;
    private ActivityResultLauncher<String> mGetContent;

    /*
    Cette méthode est appelée lorsque l'activité est créée. Elle initialise les vues, configure les écouteurs d'événements
    et lance l'activité de sélection d'image lorsque le bouton "Choisir une image" est cliqué.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        imageViewPreview = findViewById(R.id.imageViewPreview);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextPrix = findViewById(R.id.editTextPrix);
        spinnerMarque = findViewById(R.id.spinnerMarque);
        spinnerModele = findViewById(R.id.spinnerModele);
        radioGroupType = findViewById(R.id.radioGroupType);
        radioGroupEtat1 = findViewById(R.id.radioGroupEtat1);
        radioGroupEtat2 = findViewById(R.id.radioGroupEtat2);
        Button buttonChooseImage = findViewById(R.id.selectImage);
        Button buttonValider = findViewById(R.id.buttonValider);

        setupMarqueModeleSpinners();
        initializeViews();

        mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) {
                imageViewPreview.setImageURI(uri);
                imageUri = uri;
            }
        });

        buttonChooseImage.setOnClickListener(v -> mGetContent.launch("image/*"));

        buttonValider.setOnClickListener(v -> {
            if (toutEstRempli()) {
                uploadImageToFirebaseStorage(imageUri);
            } else {
                Toast.makeText(this, "Veuillez remplir tous les champs et sélectionner une image.", Toast.LENGTH_LONG).show();
            }
        });
    }

    /*
    Cette méthode initialise les vues de l'activité et configure les écouteurs d'événements pour l'image et le bouton "Valider".
     */
    private void initializeViews() {
        imageViewPreview = findViewById(R.id.imageViewPreview);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextPrix = findViewById(R.id.editTextPrix);
        spinnerMarque = findViewById(R.id.spinnerMarque);
        spinnerModele = findViewById(R.id.spinnerModele);
        radioGroupType = findViewById(R.id.radioGroupType);
        radioGroupEtat1 = findViewById(R.id.radioGroupEtat1);
        radioGroupEtat2 = findViewById(R.id.radioGroupEtat2);
        Button buttonChooseImage = findViewById(R.id.selectImage);
        Button buttonValider = findViewById(R.id.buttonValider);

        imageViewPreview.setOnClickListener(v -> mGetContent.launch("image/*"));

        buttonValider.setOnClickListener(v -> {
            if (toutEstRempli()) {
                uploadImageToFirebaseStorage(imageUri);
            } else {
                Toast.makeText(this, "Veuillez remplir tous les champs et sélectionner une image.", Toast.LENGTH_LONG).show();
            }
        });
    }

    /*
    Cette méthode configure les spinners pour les marques et les modèles en fonction du type de véhicule sélectionné (voiture ou yacht).
    Elle gère également la logique d'exclusion mutuelle entre les groupes d'options pour les états du véhicule.
     */
    private void setupMarqueModeleSpinners() {
        Map<String, List<String>> marquesEtModelesVoiture = new HashMap<>();
        Map<String, List<String>> marquesEtModelesYacht = new HashMap<>();

        marquesEtModelesVoiture.put("BMW", Arrays.asList("M3", "X5", "i8", "320i", "Z4"));
        marquesEtModelesVoiture.put("Toyota", Arrays.asList("Corolla", "Camry", "RAV4", "Supra", "Prius"));
        marquesEtModelesVoiture.put("Peugeot", Arrays.asList("208", "308", "508", "2008", "3008"));
        marquesEtModelesVoiture.put("Ferrari", Arrays.asList("488 GTB", "Portofino", "812 Superfast", "F8 Tributo", "SF90 Stradale"));
        marquesEtModelesVoiture.put("Ford", Arrays.asList("Fiesta", "Focus", "Mustang", "Explorer", "Ranger"));

        marquesEtModelesYacht.put("Azimut", Arrays.asList("Grande 35METRI", "S6", "Grande 27METRI", "55", "Magellano 25METRI"));
        marquesEtModelesYacht.put("Benetti", Arrays.asList("Delfino 95", "Diamond 145", "Luminosity", "Mediterraneo 116", "Oasis 40M"));
        marquesEtModelesYacht.put("Sunseeker", Arrays.asList("Manhattan 68", "Predator 60", "Hawk 38", "Predator 50", "Manhattan 55"));
        marquesEtModelesYacht.put("Ferretti", Arrays.asList("Ferretti 550", "Ferretti 670", "Ferretti 720", "Ferretti 780", "Ferretti 920"));
        marquesEtModelesYacht.put("Prestige", Arrays.asList("Prestige 420", "Prestige 460", "Prestige 520", "Prestige 590", "Prestige 630"));
        radioGroupType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                List<String> marques = new ArrayList<>();
                if (checkedId == R.id.radioButtonVoiture) {
                    marques.addAll(marquesEtModelesVoiture.keySet());
                } else {
                    marques.addAll(marquesEtModelesYacht.keySet());
                }

                marques.add(0, "Sélectionnez une marque");

                ArrayAdapter<String> adapterMarque = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, marques);
                spinnerMarque.setAdapter(adapterMarque);

                spinnerModele.setAdapter(null);
            }
        });

        spinnerMarque.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String marqueSelectionnee = (String) parent.getItemAtPosition(position);
                List<String> modeles = new ArrayList<>();

                if (!marqueSelectionnee.equals("Sélectionnez une marque")) {
                    if (radioGroupType.getCheckedRadioButtonId() == R.id.radioButtonVoiture) {
                        modeles.add(0, "Sélectionnez un modèle");
                        modeles.addAll(marquesEtModelesVoiture.getOrDefault(marqueSelectionnee, new ArrayList<>()));
                    } else if (radioGroupType.getCheckedRadioButtonId() == R.id.radioButtonYacht) {
                        modeles.add(0, "Sélectionnez un modèle");
                        modeles.addAll(marquesEtModelesYacht.getOrDefault(marqueSelectionnee, new ArrayList<>()));
                    }

                    ArrayAdapter<String> adapterModele = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, modeles);
                    spinnerModele.setAdapter(adapterModele);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                spinnerModele.setAdapter(null);
            }
        });

        radioGroupEtat1 = findViewById(R.id.radioGroupEtat1);
        radioGroupEtat2 = findViewById(R.id.radioGroupEtat2);

        final boolean[] isClearingCheck = {false};

        RadioGroup.OnCheckedChangeListener listener = (group, checkedId) -> {
            if (isClearingCheck[0]) {
                return;
            }

            isClearingCheck[0] = true;
            if (group == radioGroupEtat1 && radioGroupEtat1.getCheckedRadioButtonId() != -1) {
                radioGroupEtat2.clearCheck();
            } else if (group == radioGroupEtat2 && radioGroupEtat2.getCheckedRadioButtonId() != -1) {
                radioGroupEtat1.clearCheck();
            }
            isClearingCheck[0] = false;
        };

        radioGroupEtat1.setOnCheckedChangeListener(listener);
        radioGroupEtat2.setOnCheckedChangeListener(listener);


    }

    /*
    Cette méthode vérifie si tous les champs nécessaires sont remplis avant de permettre à l'utilisateur de valider l'ajout du véhicule.
     */
    private boolean toutEstRempli() {
        boolean descriptionRemplie = !editTextDescription.getText().toString().isEmpty();
        boolean prixRempli = !editTextPrix.getText().toString().trim().isEmpty();
        boolean marqueSelectionnee = spinnerMarque.getSelectedItemPosition() > 0;
        boolean modeleSelectionne = spinnerModele.getSelectedItemPosition() > 0;
        boolean typeSelectionne = radioGroupType.getCheckedRadioButtonId() != -1;

        boolean etatSelectionne = radioGroupEtat1.getCheckedRadioButtonId() != -1 || radioGroupEtat2.getCheckedRadioButtonId() != -1;
        boolean imageSelectionnee = imageUri != null;

        return descriptionRemplie && prixRempli && marqueSelectionnee && modeleSelectionne && typeSelectionne && etatSelectionne && imageSelectionnee;
    }

    /*
    Cette méthode télécharge l'image sélectionnée sur Firebase Storage et récupère l'URL de téléchargement.
     */
    private void uploadImageToFirebaseStorage(Uri selectedImageUri) {
        if (selectedImageUri == null) {
            Toast.makeText(this, "Aucune image sélectionnée", Toast.LENGTH_SHORT).show();
            return;
        }

        StorageReference storageReference = FirebaseStorage.getInstance().getReference("uploads");
        StorageReference fileReference = storageReference.child(System.currentTimeMillis() + ".jpg");

        fileReference.putFile(selectedImageUri).addOnSuccessListener(taskSnapshot -> {
            taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(uri -> {
                String imageUrl = uri.toString();
                createAndSaveVehicule(imageUrl);
            });
        }).addOnFailureListener(e -> Toast.makeText(AddActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    /*
    Cette méthode crée un objet Vehicule avec les informations saisies par l'utilisateur et l'URL de l'image téléchargée, puis l'ajoute à la base de données Firebase Realtime.
     */
    private void createAndSaveVehicule(String imageUrl) {
        String type = ((RadioButton) findViewById(radioGroupType.getCheckedRadioButtonId())).getText().toString();
        String marque = spinnerMarque.getSelectedItem().toString();
        String modele = spinnerModele.getSelectedItem().toString();
        int prix = Integer.parseInt(editTextPrix.getText().toString());
        String description = editTextDescription.getText().toString();
        String etat = ((RadioButton) findViewById(radioGroupEtat1.getCheckedRadioButtonId() != -1 ? radioGroupEtat1.getCheckedRadioButtonId() : radioGroupEtat2.getCheckedRadioButtonId())).getText().toString();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        Vehicule vehicule = new Vehicule(type, modele, marque, prix, etat, description, imageUrl,user.getUid());
        addVehiculeToFirebase(vehicule);
    }

    /*
    Cette méthode ajoute le véhicule à la base de données Firebase Realtime en utilisant une référence à la base de données.
    Elle génère un identifiant unique pour le véhicule, associe l'utilisateur actuellement connecté comme propriétaire du véhicule,
    puis sauvegarde les données dans la base de données.
    Enfin, elle affiche un message de réussite et redirige l'utilisateur vers l'activité ArticleActivity
     */
    public void addVehiculeToFirebase(Vehicule vehicule) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("vehicules");
        String vehiculeId = databaseReference.push().getKey();
        if (vehiculeId == null) {
            Toast.makeText(AddActivity.this, "Erreur lors de la génération de l'identifiant du véhicule.", Toast.LENGTH_LONG).show();
            return;
        }
        vehicule.setID(vehiculeId);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            vehicule.setUserID(user.getUid());
        }
        databaseReference.child(vehiculeId).setValue(vehicule)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(AddActivity.this, "Véhicule enregistré avec succès!", Toast.LENGTH_LONG).show();
                })
                .addOnFailureListener(e -> Toast.makeText(AddActivity.this, e.getMessage(), Toast.LENGTH_LONG).show());

        Intent intent = new Intent(this, ArticleActivity.class);
        startActivity(intent);
        finish();

    }
}
