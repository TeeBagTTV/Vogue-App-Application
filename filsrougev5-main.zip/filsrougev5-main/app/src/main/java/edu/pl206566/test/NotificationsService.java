package edu.pl206566.test;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/*
La classe NotificationsService est un service Android qui gère la réception des notifications push Firebase Cloud Messaging (FCM)
et l'enregistrement des jetons FCM des utilisateurs dans la base de données Firebase.
 */
public class NotificationsService extends FirebaseMessagingService {
    private static final String TAG = "ServiceNotifs";
    private static final String CHANNEL_ID = "my_channel_01";


    /*
    Cette méthode est appelée lorsqu'un message est reçu par le service.
    Elle vérifie d'abord si le message contient une notification (remoteMessage.getNotification()) et si c'est le cas,
    elle affiche cette notification en appelant la méthode montrerNotification().
    Ensuite, elle vérifie si le message contient des données supplémentaires (remoteMessage.getData()).
     */
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "Message reçu de : " + remoteMessage.getFrom());

        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Corps de la notification du message : " + remoteMessage.getNotification().getBody());
            montrerNotification(remoteMessage.getNotification().getTitle(), remoteMessage.getNotification().getBody());
        }

        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Données du message : " + remoteMessage.getData());
        }
    }

    /*
    Cette méthode est appelée lorsque le jeton FCM de l'appareil est mis à jour ou lorsqu'un nouveau jeton est généré pour l'appareil.
    Elle récupère l'ID de l'utilisateur connecté (s'il y en a un) à partir de FirebaseAuth
    et enregistre le nouveau jeton FCM dans la base de données Firebase en appelant la méthode saveTokenToDatabase().
     */
    @Override
    public void onNewToken(@NonNull String token) {
        Log.d(TAG, "Le nouveau token de l'appareil: " + token);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            saveTokenToDatabase(userId, token);
        }   else {
        Log.d(TAG, "Aucun utilisateur connecté, impossible d'enregistrer le token FCM.");
        }

    }

    /*
    Cette méthode enregistre le jeton FCM de l'utilisateur dans la base de données Firebase sous le nœud correspondant à son ID utilisateur.
     */
    private void saveTokenToDatabase(String userId, String token) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId);
        databaseReference.child("token").setValue(token).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Log.d(TAG, "Token FCM mis à jour avec succès dans la base de données.");
            } else {
                Log.d(TAG, "Échec de la mise à jour du token FCM dans la base de données.");
            }
        });
    }

    /*
    Cette méthode crée et affiche une notification en utilisant le NotificationManager.
    Elle crée également un canal de notification si l'appareil exécute Android Oreo (API 26) ou une version ultérieure.
    La notification affiche le titre et le message passés en paramètres.
     */
    private void montrerNotification(String titre, String message) {
        Log.d(TAG, "Début de la méthode montrerNotification");

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (notificationManager == null) {
            Log.e(TAG, "NotificationManager est null, impossible de montrer la notification");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Mon Canal";
            String description = "Description du Canal";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(titre)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        int notificationId = (int) System.currentTimeMillis();
        notificationManager.notify(notificationId, builder.build());
    }
}
