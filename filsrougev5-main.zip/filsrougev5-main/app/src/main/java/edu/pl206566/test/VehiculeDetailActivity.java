package edu.pl206566.test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

/*
La classe VehiculeDetailActivity est une activité qui affiche les détails d'un véhicule sélectionné,
ainsi que des fonctionnalités pour la location et la notation du véhicule.
 */
public class VehiculeDetailActivity extends AppCompatActivity {

    private RatingBar ratingBar;
    private Button finLocBtn;
    private TextView textRating;

    /*
    Cette méthode est appelée lors de la création de l'activité.
    Elle récupère les éléments d'interface utilisateur de la mise en page XML.
    Elle récupère l'objet Vehicule envoyé à cette activité à l'aide de getParcelableExtra().
    Elle utilise Picasso pour charger l'image du véhicule à partir de l'URL spécifiée dans l'objet Vehicule et l'afficher dans l'ImageView.
    Elle affiche les détails du véhicule (type, marque, modèle, prix, état, description) dans les TextView correspondants.
    Elle définit des listeners pour le bouton de location (louer) et le bouton de fin de location (finLocBtn).
    Lorsque le bouton de location est cliqué, le ratingBar et le bouton de fin de location deviennent visibles.
    Lorsque le bouton de fin de location est cliqué, la note donnée par l'utilisateur est récupérée à partir du ratingBar,
    puis la méthode updateVehicleAfterRent() est appelée pour mettre à jour les informations du véhicule dans la base de données Firebase.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_loc);

        ratingBar = findViewById(R.id.ratingBar);
        finLocBtn = findViewById(R.id.fin);
        textRating = findViewById(R.id.textRating);

        Vehicule vehicule = getIntent().getParcelableExtra("SelectedCar");
        Button louer = findViewById(R.id.louer);

        ratingBar.setVisibility(View.GONE);
        finLocBtn.setVisibility(View.GONE);

        if (vehicule != null) {
            ImageView vehicleImage = findViewById(R.id.vehicleImage);
            TextView tvType = findViewById(R.id.tvType);
            TextView tvMarque = findViewById(R.id.tvMarque);
            TextView tvModele = findViewById(R.id.tvModele);
            TextView tvPrix = findViewById(R.id.tvPrix);
            TextView tvEtat = findViewById(R.id.tvEtat);
            TextView tvDescription = findViewById(R.id.tvDescription);

            Picasso.get().load(vehicule.getPicture()).into(vehicleImage);
            tvType.setText(String.format("Type : %s", vehicule.getType_vehicule()));
            tvMarque.setText(String.format("Marque : %s", vehicule.getMarque()));
            tvModele.setText(String.format("Modèle : %s", vehicule.getModele()));
            tvPrix.setText(String.format("Prix : %d €/jour", vehicule.getPrix()));
            tvEtat.setText(String.format("État : %s", vehicule.getEtat()));
            tvDescription.setText(String.format("Description : %s", vehicule.getDescription()));


            louer.setOnClickListener(v -> {
                louer.setVisibility(View.GONE);
                ratingBar.setVisibility(View.VISIBLE);
                finLocBtn.setVisibility(View.VISIBLE);
                textRating.setVisibility(View.VISIBLE);
            });

            finLocBtn.setOnClickListener(v -> {
                float rating = ratingBar.getRating();
                if (rating == 0) {
                    Toast.makeText(this, "Veuillez sélectionner une note.", Toast.LENGTH_SHORT).show();
                    return;
                }
                updateVehicleAfterRent(vehicule, rating);
            });
        } else {
            Toast.makeText(this, "Erreur lors de la récupération des données du véhicule.", Toast.LENGTH_LONG).show();
        }
    }



    /*
    Cette méthode est appelée lorsqu'un utilisateur souhaite finir la location d'un véhicule et noter son expérience.
    Elle met à jour les informations du véhicule dans la base de données Firebase, notamment le champ locID, le total des notes, le nombre de notes et la note moyenne.
    Elle crée un objet Map contenant les mises à jour à effectuer dans la base de données.
    Elle utilise une référence à la base de données Firebase pour mettre à jour les données du véhicule.
    Elle affiche un message toast pour informer l'utilisateur du succès ou de l'échec de la mise à jour des informations du véhicule.
     */
    private void updateVehicleAfterRent(Vehicule vehicule, float newRating) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("vehicules").child(vehicule.getID());

        ref.child("locID").setValue("0");

        double newSumRatings = vehicule.getSumRatings() + newRating;

        int newNbRatings = vehicule.getNbRatings() + 1;

        double newRatingAverage = newSumRatings / newNbRatings;

        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("sumRatings", newSumRatings);
        updateMap.put("nbRatings", newNbRatings);
        updateMap.put("rating", newRatingAverage);

        ref.updateChildren(updateMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(VehiculeDetailActivity.this, "Note mise à jour avec succès.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(VehiculeDetailActivity.this, ArticleActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(VehiculeDetailActivity.this, "Erreur lors de la mise à jour du véhicule.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

