package edu.pl206566.test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

/*
La classe DetailActivity est une activité Android qui affiche les détails d'un véhicule sélectionné.
 */
public class DetailActivity extends AppCompatActivity {

    /*
    Cette méthode est appelée lorsque l'activité est créée.
    Elle initialise les vues, récupère les données du véhicule sélectionné à partir de l'intent,
    affiche les détails du véhicule, gère l'affichage de la note du véhicule à partir de la base de données Firebase,
    gère l'affichage des boutons en fonction de l'appartenance du véhicule à l'utilisateur connecté,
    et configure les écouteurs d'événements pour le bouton "Louer" et le bouton "Supprimer".
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Button louer = findViewById(R.id.louer);
        ImageView vehicleImage = findViewById(R.id.vehicleImage);
        TextView tvType = findViewById(R.id.tvType);
        TextView tvMarque = findViewById(R.id.tvMarque);
        TextView tvModele = findViewById(R.id.tvModele);
        TextView tvPrix = findViewById(R.id.tvPrix);
        TextView tvEtat = findViewById(R.id.tvEtat);
        TextView tvDescription = findViewById(R.id.tvDescription);
        TextView appartenance = findViewById(R.id.texte_appartenance);
        Button delete = findViewById(R.id.delete_bouton);
        delete.setVisibility(View.GONE);
        TextView tvRating = findViewById(R.id.tvRating);


        Vehicule vehicule = getIntent().getParcelableExtra("SelectedCar");

        Picasso.get().load(vehicule.getPicture()).into(vehicleImage);

        tvType.setText(String.format("Type : %s", vehicule.getType_vehicule()));
        tvMarque.setText(String.format("Marque : %s", vehicule.getMarque()));
        tvModele.setText(String.format("Modèle : %s", vehicule.getModele()));
        tvPrix.setText(String.format("Prix : %d €/jour", vehicule.getPrix()));
        tvEtat.setText(String.format("État : %s", vehicule.getEtat()));
        tvDescription.setText(String.format("Description : %s", vehicule.getDescription()));

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("vehicules").child(vehicule.getID());
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Vehicule updatedVehicule = dataSnapshot.getValue(Vehicule.class);
                    if (updatedVehicule != null) {
                        double rating = updatedVehicule.getRating();
                        tvRating.setText(String.format("Note : %.1f/5", rating));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(DetailActivity.this, "Erreur lors du chargement de la note.", Toast.LENGTH_SHORT).show();
            }
        });

        /*
        Cette méthode supprime le véhicule de la base de données Firebase lorsque le bouton "Supprimer" est cliqué.
         */
        delete.setOnClickListener(v -> {
            deleteCarFromFirebase(vehicule.getID());
            Intent intent = new Intent(this, ArticleActivity.class);
            startActivity(intent);
            finish();
        });

        /*
        Cette ligne récupère l'utilisateur actuellement connecté.
         */
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (vehicule != null && user != null) {
            String vehiculeUserID = vehicule.getUserID();
            String currentUserID = user.getUid();

            if (vehiculeUserID != null && currentUserID.equals(vehiculeUserID)) {
                louer.setEnabled(false);
                appartenance.setText("Ce véhicule vous appartient");
                delete.setVisibility(View.VISIBLE);
            } else {
                /*
                Cette méthode gère la location du véhicule lorsque le bouton "Louer" est cliqué.
                Elle met à jour la base de données Firebase avec l'ID de l'utilisateur qui a loué le véhicule.
                 */
                louer.setOnClickListener(view -> {
                    String vehiculeID = vehicule.getID();
                    if (vehiculeID != null) {
                        DatabaseReference vehiculeRef = FirebaseDatabase.getInstance().getReference("vehicules").child(vehiculeID);
                        vehiculeRef.child("locID").setValue(currentUserID, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                if (databaseError == null) {
                                    Toast.makeText(DetailActivity.this, "Véhicule loué avec succès!", Toast.LENGTH_SHORT).show();

                                    changeActivity();

                                } else {
                                    Toast.makeText(DetailActivity.this, "Échec de la location du véhicule.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    } else {
                        Toast.makeText(DetailActivity.this, "Erreur: ID du véhicule non trouvé.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            Toast.makeText(this, "Erreur lors de la récupération des données du véhicule ou de l'utilisateur.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    /*
    Cette méthode supprime le véhicule de la base de données FireBase
     */
    private void deleteCarFromFirebase(String carId) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("vehicules").child(carId);

        ref.removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(DetailActivity.this, "Voiture supprimée avec succès.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DetailActivity.this, "Échec de la suppression de la voiture.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /*
     Cette méthode change l'activité actuelle pour revenir à l'activité ArticleActivity après avoir effectué une action.
     */
    public void changeActivity(){
        Intent intent = new Intent(this, ArticleActivity.class);
        startActivity(intent);
        finish();
    }

}
