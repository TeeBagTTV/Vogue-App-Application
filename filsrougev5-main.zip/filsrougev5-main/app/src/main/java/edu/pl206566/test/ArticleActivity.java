package edu.pl206566.test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/*
La classe ArticleActivity est une activité Android qui affiche une liste de véhicules disponibles à la location.
 */
public class ArticleActivity extends AppCompatActivity {
    private VehiculeAdapter adapter;
    List<Vehicule> listeVehiculeAll = new ArrayList<>();
    List<Vehicule> listeVehiculeShow = new ArrayList<>();
    private ListView listView;
    private Button louer;
    private Button deconnecte;
    private Button mesLoc;


    /*
    Cette méthode est appelée lorsque l'activité est créée. Elle initialise les vues,
    configure les écouteurs d'événements pour les boutons "Louer" et "Mes locations",
    affiche le pseudo de l'utilisateur connecté, récupère les données des véhicules à partir de la base de données Firebase,
    et met à jour l'interface utilisateur avec la liste des véhicules.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activty_article);
        listView = findViewById(R.id.listView);

        louer = findViewById(R.id.louer);
        deconnecte = findViewById(R.id.btn_logout);
        mesLoc = findViewById(R.id.reserve);

        TextView pseudo = findViewById(R.id.pseudo);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String email = user.getEmail();
            if (email != null && !email.isEmpty()) {
                String partieAvantArobase = email.split("@")[0];
                String pseudoLimite = partieAvantArobase.substring(0, Math.min(partieAvantArobase.length(), 7));
                pseudo.setText(pseudoLimite);
            }
        }

        /*
        Cette méthode lance l'activité AddActivity lorsque le bouton "Louer" est cliqué.
         */
        louer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivity(intent);
            }
        });

        /*
        Cette méthode lance l'activité ListeLocActivity lorsque le bouton "Mes locations" est cliqué.
         */
        mesLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ListeLocActivity.class);
                startActivity(intent);
            }
        });


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("vehicules");

        /*
        Cette méthode récupère les données des véhicules à partir de la base de données Firebase
        et les met à jour dans l'interface utilisateur en utilisant un adaptateur personnalisé.
         */
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<Vehicule> carList = new ArrayList<>();
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    Vehicule car = child.getValue(Vehicule.class);
                    carList.add(car);
                }

                adapter = new VehiculeAdapter(ArticleActivity.this, R.layout.activty_article, carList);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ArticleActivity.this, "Failed to load vehicles.", Toast.LENGTH_SHORT).show();
            }
        });


        /*
        Cette méthode gère le clic sur un élément de la liste des véhicules
        et lance l'activité DetailActivity pour afficher les détails du véhicule sélectionné.
         */
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Vehicule selectedCar = adapter.getItem(position);

                Intent intent = new Intent(ArticleActivity.this, DetailActivity.class);
                intent.putExtra("SelectedCar", selectedCar);
                startActivity(intent);
            }
        });


        /*
        Cette méthode gère la déconnexion de l'utilisateur en appelant la méthode signOut() de Firebase Auth,
        puis redirige l'utilisateur vers l'activité de connexion LoginActivity.
         */
        deconnecte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


    }
}
