package edu.pl206566.test;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/*
La classe ListeLocActivity est une activité Android qui affiche la liste des véhicules loués par l'utilisateur actuellement connecté.
 */
public class ListeLocActivity extends AppCompatActivity {
    private VehiculeAdapter adapter;
    private ListView listView;

    /*
    Cette méthode est appelée lorsque l'activité est créée.
    Elle configure la mise en page en associant la vue ListView de l'interface utilisateur et initialise une instance
    de FirebaseDatabase pour récupérer les données des véhicules depuis la base de données Firebase.
    Elle vérifie également si un utilisateur est connecté. Si oui, elle récupère l'ID de l'utilisateur actuel et
    filtre la liste des véhicules pour ne montrer que ceux qui ont été loués par cet utilisateur. *
    Ensuite, elle crée un adaptateur personnalisé (VehiculeAdapter) pour afficher ces véhicules dans la ListView.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loc);

        listView = findViewById(R.id.listView);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("vehicules");

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            String currentUserId = currentUser.getUid();

            myRef.addValueEventListener(new ValueEventListener() {

                /*
                Cette méthode est appelée chaque fois que les données des véhicules changent dans la base de données Firebase.
                Elle parcourt les enfants de la référence de base de données "vehicules", récupère chaque véhicule et
                vérifie s'il a été loué par l'utilisateur actuel. Si c'est le cas, le véhicule est ajouté à une liste filtrée.
                Ensuite, cette liste filtrée est utilisée pour initialiser l'adaptateur personnalisé et mettre à jour la ListView.
                 */
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    List<Vehicule> filteredList = new ArrayList<>();
                    for (DataSnapshot child : dataSnapshot.getChildren()) {
                        Vehicule car = child.getValue(Vehicule.class);
                        if (car != null && currentUserId.equals(car.getLocID())) {
                            filteredList.add(car);
                        }
                    }

                    adapter = new VehiculeAdapter(ListeLocActivity.this, R.layout.vehicule_layout, filteredList);
                    listView.setAdapter(adapter);
                }

                /*
                Cette méthode est appelée en cas d'erreur lors de la récupération des données depuis la base de données Firebase.
                Elle affiche un message d'erreur toast pour informer l'utilisateur.
                 */
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(ListeLocActivity.this, "Erreur chargement vehicules.", Toast.LENGTH_SHORT).show();
                }
            });
        } else {

        }

        /*
         Cette méthode est appelée lorsque l'utilisateur clique sur un élément de la ListView.
         Elle récupère le véhicule sélectionné à partir de l'adaptateur et
         crée une intention pour démarrer l'activité VehiculeDetailActivity, en passant le véhicule sélectionné en tant qu'extra.
         */
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Vehicule selectedCar = adapter.getItem(position);

                Intent intent = new Intent(ListeLocActivity.this, VehiculeDetailActivity.class);
                intent.putExtra("SelectedCar", selectedCar);
                startActivity(intent);
            }
        });
    }
}
