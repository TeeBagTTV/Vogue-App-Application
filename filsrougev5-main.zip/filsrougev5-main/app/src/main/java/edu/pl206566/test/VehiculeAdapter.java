package edu.pl206566.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Locale;

/*
La classe VehiculeAdapter est un adaptateur personnalisé utilisé pour afficher une liste de véhicules
dans une vue ListView ou GridView.
 */
public class VehiculeAdapter extends ArrayAdapter<Vehicule> {
    private List<Vehicule> listVehicule;

    /*
    Prend en paramètres le contexte de l'application, l'identifiant de la ressource de mise en page pour chaque élément de la liste
    (resource) et la liste des véhicules à afficher.
     */
    public VehiculeAdapter(Context context, int resource, List<Vehicule> listVehicule) {
        super(context, resource, listVehicule);
        this.listVehicule = listVehicule;
    }


    /*
    Cette méthode est appelée pour chaque élément de la liste et est responsable de l'affichage de chaque élément dans la vue.
    Elle récupère le véhicule correspondant à la position actuelle dans la liste.
    Si la vue n'est pas recyclée (convertView == null), elle est inflatée à partir du fichier de mise en page vehicule_layout.xml.
    Elle obtient les références des vues à l'intérieur de l'élément de la liste (image, texte, etc.).
    Elle utilise Picasso pour charger l'image du véhicule à partir de l'URL spécifiée dans l'objet Vehicule et l'afficher dans l'ImageView correspondant.
    Elle définit le texte des TextView pour afficher les détails du véhicule (marque, état, prix, description).
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Vehicule vehicule = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.vehicule_layout, parent, false);
        }

        ImageView picture = convertView.findViewById(R.id.picture);
        TextView marque = convertView.findViewById(R.id.marque);
        TextView etat = convertView.findViewById(R.id.etat);
        TextView prix = convertView.findViewById(R.id.prix);
        TextView ratingBar = convertView.findViewById(R.id.ratingBar);
        TextView description = convertView.findViewById(R.id.description);

        Picasso.get().load(vehicule.getPicture()).into(picture);

        marque.setText(vehicule.getMarque() + " - " + vehicule.getModele());
        etat.setText(vehicule.getEtat());
        prix.setText(vehicule.getPrix() + "€/j");

        description.setText(vehicule.getDescription());

        return convertView;
    }
}
